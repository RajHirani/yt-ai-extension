from dotenv import load_dotenv
from langchain_community.document_loaders import YoutubeLoader

from model.ask_question_req import AskQuestionReq
from splitter import split

load_dotenv()
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import PromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_huggingface.chat_models import ChatHuggingFace
from langchain_huggingface import HuggingFaceEndpoint
from vectorestore import get_retriever, video_exists, store_documents
from loaders import load

llm = ChatHuggingFace(llm=HuggingFaceEndpoint(
    repo_id="Qwen/Qwen2.5-7B-Instruct",
    task="text-generation",
))

prompt = PromptTemplate(
    template="""
You are AI bot which helps user to understand the video by having transcripts
Use the following context to answer the question. if context is not given than simply say you dont know.
Context:
{context}

Question:
{question}

Answer:
""",
    input_variables=["context", "question"]
)

def askQuestion(askQuestionReq : AskQuestionReq):
    rag_chain = (
            {"context": get_retriever(askQuestionReq.video_id), "question": RunnablePassthrough()}
            | prompt
            | llm
            | StrOutputParser()
    )
    result = rag_chain.invoke(askQuestionReq.query)
    print(result)
    return result


def check_and_store_transcript(url: str):
    youtubeId = YoutubeLoader.extract_video_id(url)

    if video_exists(youtubeId):
        print(youtubeId)
        return youtubeId
    #Load the Video
    content = load(url)
    #Split the documents
    documents = split(content)
    #generate embeddings and store it
    store_documents(documents)
    print("Video Encodings stored")
    return youtubeId