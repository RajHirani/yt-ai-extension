from pydantic import BaseModel, Field


class ProcessVideoReqBody(BaseModel):
    url: str = Field()
