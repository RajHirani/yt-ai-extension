from pydantic import BaseModel, Field


class AskQuestionReq(BaseModel):
    video_id: str = Field()
    query: str = Field()
