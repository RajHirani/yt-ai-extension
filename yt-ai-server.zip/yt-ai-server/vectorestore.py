from langchain_chroma import Chroma
from embeddings import embeddings

vectordb = Chroma(
    persist_directory="./chroma_db",
    embedding_function=embeddings
)

def store_documents(documents):
    vectordb.add_documents(documents)

def video_exists(video_id: str):
    results = vectordb.get(
        where={"source": video_id},
        limit=1
    )

    return len(results["ids"]) > 0

def get_retriever(video_id: str):
    return vectordb.as_retriever(
        search_type="mmr",
        search_kwargs={
            "k": 3,
            "filter": {"source": video_id}
        }

    )