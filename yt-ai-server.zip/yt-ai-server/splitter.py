from langchain_core import documents
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)

def split(content: list[Document]):
    return text_splitter.split_documents(content)