from langchain_community.document_loaders import YoutubeLoader


def load(youtubeUrl: str):
    loader = YoutubeLoader.from_youtube_url(
        youtube_url = youtubeUrl,
    )
    return loader.load()