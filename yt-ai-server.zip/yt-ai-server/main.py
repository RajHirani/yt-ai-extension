from dotenv import load_dotenv

from llm import check_and_store_transcript, askQuestion
from model.ask_question_req import AskQuestionReq
from model.process_video_req import ProcessVideoReqBody

load_dotenv()
from fastapi import FastAPI

url = "https://www.youtube.com/watch?v=1bUy-1hGZpI"

app = FastAPI(title="My API", version="1.0.0")

@app.get("/")
def read_root():
    return {"message": "Hello, FastAPI!"}


@app.post("/process-video")
def process_video(process_video_req : ProcessVideoReqBody):
    youtubeid = check_and_store_transcript(process_video_req.url)
    return {"youtubeId": youtubeid}

@app.post("/ask")
def ask(ask_question_req : AskQuestionReq):
    ans = askQuestion(ask_question_req)
    return { "answer": ans }